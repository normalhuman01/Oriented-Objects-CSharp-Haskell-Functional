

#include "IDictionary.h"

IDictionary::~IDictionary()
{
    
}
