#ifndef TIPOOPERACION_H
#define TIPOOPERACION_H


enum TipoOperacion
{
    su,
    re,
    di,
    mu
};

#endif // TIPOOPERACION_H
