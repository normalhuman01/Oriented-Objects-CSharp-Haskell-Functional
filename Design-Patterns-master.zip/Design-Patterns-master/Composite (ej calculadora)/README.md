![Diagrama de clases del Composite](https://raw.githubusercontent.com/mathiasuy/Design-Patterns/master/Composite%20(ej%20calculadora)/diagrama.png)
