![Diagrama de clases del patrón](https://raw.githubusercontent.com/mathiasuy/Design-Patterns/master/Adapter%20(Wrapper)/diagrama.png)
