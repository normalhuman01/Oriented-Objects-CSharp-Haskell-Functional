![Diagrama de clases del patrón](https://raw.githubusercontent.com/mathiasuy/Design-Patterns/master/Template%20Method%20(%20ej%20navegador)/diagrama.png)
