# Design-Patterns

* Patrones de diseño 
* Clase Template C++ 
* Parciales / 
* Exámenes de Programación 4 de [Facultad de Ingeniería UdelaR - Uruguay](https://eva.fing.edu.uy/mod/folder/view.php?id=24662). 

* Análisis, Diseño e implementación en C++  ( `Usando programación orientada a objetos` ). 

* UML. Design Patterns, Template C++, ejercicios...
