#ifndef TIPOESTADO_H
#define TIPOESTADO_H

enum TipoEstado
{
    BUENO,
    INTERMEDIO,
    MALO
};

#endif // TIPOESTADO_H
