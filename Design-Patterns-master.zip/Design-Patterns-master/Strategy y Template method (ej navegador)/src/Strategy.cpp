#include "Strategy.h"

Strategy::~Strategy()
{
    //dtor
}
