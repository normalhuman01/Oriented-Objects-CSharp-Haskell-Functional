![Diagrama de clases del patrón](https://raw.githubusercontent.com/mathiasuy/Design-Patterns/master/Strategy%20y%20Template%20method%20(ej%20navegador)/diagrama.png)
