#include "OptimizadorVolumen.h"

	OptimizadorVolumen::~OptimizadorVolumen(){

	};