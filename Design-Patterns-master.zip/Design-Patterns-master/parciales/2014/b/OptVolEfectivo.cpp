#include "OptVolEfectivo.h"

OptVolEfectivo::OptVolEfectivo(){}
OptVolEfectivo::~OptVolEfectivo(){}

double OptVolEfectivo::volOptimo(set<Paquete*> lp){

}