#include "Paquete.h"

Paquete::Paquete(){};
Paquete::~Paquete(){};