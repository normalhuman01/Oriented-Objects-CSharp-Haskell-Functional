#include "OptVolEficiente.h"

OptVolEficiente::OptVolEficiente(){}
OptVolEficiente::~OptVolEficiente(){}

double OptVolEficiente::volOptimo(set<Paquete*> lp){

}

