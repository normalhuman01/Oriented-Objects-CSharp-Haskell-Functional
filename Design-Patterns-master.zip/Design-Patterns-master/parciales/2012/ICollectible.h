class ICollectible{
	virtual ~ICollectible();
}