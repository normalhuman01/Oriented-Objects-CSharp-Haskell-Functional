#include "Event.h"

class EventoCompra : public Event{
	private:
		int idProducto;
		int cant;
}