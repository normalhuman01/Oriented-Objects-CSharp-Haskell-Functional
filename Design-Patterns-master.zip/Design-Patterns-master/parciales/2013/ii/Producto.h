class Producto{
	private:
		int id;
		int stock;
}