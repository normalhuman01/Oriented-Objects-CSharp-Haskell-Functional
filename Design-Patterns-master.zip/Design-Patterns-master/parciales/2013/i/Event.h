class Event{
	private:
		bool cancelled;
	public:
		cancel();

		virtual ~Event();
}