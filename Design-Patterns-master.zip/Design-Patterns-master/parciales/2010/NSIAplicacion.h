class NSIAplicacion{
public:
	virtual void actualizarContenido()=0;
	virtual ~NSIAplicacion();
}