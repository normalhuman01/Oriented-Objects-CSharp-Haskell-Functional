![Diagrama de clases del patrón](https://github.com/mathiasuy/parciales-fing-p4/blob/master/2010/diagrama.png?raw=true)

