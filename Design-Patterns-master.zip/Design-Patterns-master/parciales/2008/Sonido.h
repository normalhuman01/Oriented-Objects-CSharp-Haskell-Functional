#include "Recurso.h"

class Sonido : public Recurso{
public:
	void cargar();
	void cargarEspecifico();
}