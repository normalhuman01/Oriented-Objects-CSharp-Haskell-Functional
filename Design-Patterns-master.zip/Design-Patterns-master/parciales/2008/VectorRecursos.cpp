VectorRecursos::VectorRecursos();

VectorRecursos::~VectorRecursos();

void VectorRecursos::add(Recurso* r){

}

void VectorRecursos::remove(Recurso* r){

}

bool VectorRecursos::member(Recurso* r){

}

int VectorRecursos::size(){

}

Recurso* VectorRecursos::getElement(int i){
	
}