class Video{
	public:
		void load(string name);
		Video();
		virtual ~Video();
}