<p align="center"> 
<img src="https://github.com/mathiasuy/parciales-fing-p4/blob/master/2006/diagrama.png?raw=true" alt="diagrama uml"></img>
</p>
