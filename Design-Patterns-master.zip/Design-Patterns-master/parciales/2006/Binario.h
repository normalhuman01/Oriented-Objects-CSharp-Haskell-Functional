class Binario : public Documento{
public:
	Binario(string,string);
	virtual ~Binario();
}