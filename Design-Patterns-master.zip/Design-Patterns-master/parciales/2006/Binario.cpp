	Binario::Binario(string,string):nombre(a),descripcion(b){};
	
	Binario::~Binario(){};