	Cambios::Cambios(Date a):fecha(a){};
	Cambios::~Cambios(){};