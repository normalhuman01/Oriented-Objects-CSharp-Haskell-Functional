#include "DataItemProd.h"

class DataItemProdFijo : public DataItemProd{
	public:
		DataItemProd(int);
		virtual ~DataItemProd();
}