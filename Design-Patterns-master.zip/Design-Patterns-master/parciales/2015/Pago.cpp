Pago::Pago(float a){
	this->monto = a;
};

Pago::~Pago(){};