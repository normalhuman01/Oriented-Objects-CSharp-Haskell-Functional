enum TTarjeta{
	Viza,
	MastroCar,
	Oka
}