float Posicion::getX(){
	return this->x;
};

float Posicion::getY(){
	return this->y;
};

Posicion::Posicion(float x,float y){
	this->x = x;
	this->y = y;
};

Posicion::~Posicion(){};