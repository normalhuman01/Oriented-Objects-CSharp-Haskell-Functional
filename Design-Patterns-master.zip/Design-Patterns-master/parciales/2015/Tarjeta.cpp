Tarjeta::Tarjeta(float a, TTarjeta t):Pago(a){
	this->tarjeta = t;
};

Tarjeta::~Tarjeta(){};