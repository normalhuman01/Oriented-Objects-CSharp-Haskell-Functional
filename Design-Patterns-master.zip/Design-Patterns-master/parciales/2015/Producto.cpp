Producto::Producto(string a,string b,float c,cantidad d){
	this->nombre = a;
	this->descr = b;
	this->precio = c;
	this->cantidad = d;
};

Producto::~Producto(){};