Contado::Contado(float,float):Pago(a){
	this->descuento = b;
};

Contado::~Contado(){};