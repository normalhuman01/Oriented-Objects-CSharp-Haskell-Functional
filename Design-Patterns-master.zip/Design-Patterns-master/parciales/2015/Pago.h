class Pago
{
	private:
		float monto;
	public:
		Pago(float);
		virtual ~Pago();
	
};