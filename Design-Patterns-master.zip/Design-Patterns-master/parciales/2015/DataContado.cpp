float DataContado::getDescuento(){
	return this->descuento;
};

void DataContado::DataContado(float a){
	this->descuento = a;
};

 DataContado::~DataContado(){};