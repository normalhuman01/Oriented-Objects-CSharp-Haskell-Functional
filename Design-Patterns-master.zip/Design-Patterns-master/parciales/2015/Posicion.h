class Posicion{
	private:
		float x, y;
	public:
		float getX();
		float getY();
		Posicion(float,float);
		virtual ~Posicion();
}