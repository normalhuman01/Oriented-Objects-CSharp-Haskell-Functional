TTarjeta DataTarjeta::getTarjeta(){
	return this->tarjeta;
};

DataTarjeta::DataTarjeta(TTarjeta a){
	this->tarjeta = a;
};

DataTarjeta::~DataTarjeta(){};