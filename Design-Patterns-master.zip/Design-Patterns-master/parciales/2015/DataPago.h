class DataPago{
	private:
		float monto;
	public:
		float getMonto();
		DataPago(float);
		virtual ~DataPago();
}