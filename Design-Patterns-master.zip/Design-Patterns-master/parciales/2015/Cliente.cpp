
Cliente::Cliente(string a,string b,string c,string d,Posicion e){
	this->ci = a;
	this->nombre = b;
	this->tel = c;
	this->dir = d;
	this->dirMapa = e;
};

Cliente::~Cliente(){}