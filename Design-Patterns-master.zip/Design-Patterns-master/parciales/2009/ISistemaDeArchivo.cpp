#include "ISistemaDeArchivo.h"
ISistemaDeArchivo::~ISistemaDeArchivo(){};
