	Elemento::Elemento(int i): id(i){ // PROBAR
	};

	Elemento::~Elemento(){};