class Imagen{
public:
	virtual ~Imagen();
}