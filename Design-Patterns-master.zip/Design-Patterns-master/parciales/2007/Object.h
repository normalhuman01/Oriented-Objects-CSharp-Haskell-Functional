class Object{
public:
	Object* copiar();
	virtual ~Object();
}