Imagen::~Imagen(){};
