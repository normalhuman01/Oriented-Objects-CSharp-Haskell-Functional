class Utils{
public:
	static Imagen* copiarImagen(Imagen* img);
	virtual ~Utils();
}