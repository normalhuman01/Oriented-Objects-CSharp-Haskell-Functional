#include "IObserver.h"

IObserver::IObserver()
{
    //ctor
}

IObserver::~IObserver()
{
    //dtor
}
