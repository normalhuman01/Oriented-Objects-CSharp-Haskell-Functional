#include "ISubject.h"

ISubject::ISubject()
{
    //ctor
}

ISubject::~ISubject()
{
    //dtor
}
