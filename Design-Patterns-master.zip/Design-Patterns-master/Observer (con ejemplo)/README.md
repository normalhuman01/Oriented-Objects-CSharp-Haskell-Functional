![Diagrama de clases del Composite](https://github.com/mathiasuy/Design-Patterns/blob/master/Observer%20(con%20ejemplo)/diagrama.png)
