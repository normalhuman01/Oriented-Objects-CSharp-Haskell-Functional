![Diagrama de clases del patrón](https://raw.githubusercontent.com/mathiasuy/Design-Patterns/master/Proxy%20(ej%20impresoras)/diagrama.png)
