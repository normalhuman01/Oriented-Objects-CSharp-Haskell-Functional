#include "IImpresora.h"

IImpresora::~IImpresora()
{
    //dtor
}
