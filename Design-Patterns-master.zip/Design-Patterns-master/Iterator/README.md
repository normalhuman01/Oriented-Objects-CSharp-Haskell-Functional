![Diagrama de clases del patrón](diagrama.png)

Diagrama de Wikipedia.
