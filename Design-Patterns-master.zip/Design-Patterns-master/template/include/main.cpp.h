#ifndef MAIN_CPP_H
#define MAIN_CPP_H


class main
{
    public:
        main();
        virtual ~main();

    protected:

    private:
};

#endif // MAIN_CPP_H
