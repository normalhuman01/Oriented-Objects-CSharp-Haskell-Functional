![Diagrama de clases del patrón](https://raw.githubusercontent.com/mathiasuy/Design-Patterns/master/State%20y%20Singleton%20v2%20(ej%20reloj)/diagrama.png)
